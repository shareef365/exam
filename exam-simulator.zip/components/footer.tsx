import Link from "next/link"

export default function Footer() {
  return (
    <footer className="border-t bg-background">
      <div className="container px-4 py-8 md:px-6 md:py-12">
        <div className="grid gap-8 sm:grid-cols-2 md:grid-cols-4">
          <div className="space-y-4">
            <h3 className="text-lg font-bold">ExamSim</h3>
            <p className="text-sm text-muted-foreground">
              The most realistic exam simulator for competitive exams in India.
            </p>
          </div>
          <div className="space-y-4">
            <h3 className="text-lg font-bold">Quick Links</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <Link href="/exams" className="text-muted-foreground hover:text-foreground">
                  All Exams
                </Link>
              </li>
              <li>
                <Link href="/pricing" className="text-muted-foreground hover:text-foreground">
                  Pricing
                </Link>
              </li>
              <li>
                <Link href="/about" className="text-muted-foreground hover:text-foreground">
                  About Us
                </Link>
              </li>
              <li>
                <Link href="/contact" className="text-muted-foreground hover:text-foreground">
                  Contact
                </Link>
              </li>
            </ul>
          </div>
          <div className="space-y-4">
            <h3 className="text-lg font-bold">Exams</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <Link href="/exams/jee" className="text-muted-foreground hover:text-foreground">
                  JEE Main & Advanced
                </Link>
              </li>
              <li>
                <Link href="/exams/neet" className="text-muted-foreground hover:text-foreground">
                  NEET
                </Link>
              </li>
              <li>
                <Link href="/exams/eamcet-ap" className="text-muted-foreground hover:text-foreground">
                  EAMCET (AP)
                </Link>
              </li>
              <li>
                <Link href="/exams/eamcet-ts" className="text-muted-foreground hover:text-foreground">
                  EAMCET (TS)
                </Link>
              </li>
            </ul>
          </div>
          <div className="space-y-4">
            <h3 className="text-lg font-bold">Legal</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <Link href="/terms" className="text-muted-foreground hover:text-foreground">
                  Terms of Service
                </Link>
              </li>
              <li>
                <Link href="/privacy" className="text-muted-foreground hover:text-foreground">
                  Privacy Policy
                </Link>
              </li>
              <li>
                <Link href="/refund" className="text-muted-foreground hover:text-foreground">
                  Refund Policy
                </Link>
              </li>
            </ul>
          </div>
        </div>
        <div className="mt-8 border-t pt-8 text-center text-sm text-muted-foreground">
          <p>© {new Date().getFullYear()} ExamSim. All rights reserved.</p>
        </div>
      </div>
    </footer>
  )
}
